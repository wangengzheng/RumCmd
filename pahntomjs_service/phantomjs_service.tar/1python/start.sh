#! /bin/sh


python index.py 8765 &
